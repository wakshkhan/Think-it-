import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Gift, IndianRupee, BadgeCheck, Trophy } from "lucide-react";
import { motion } from "framer-motion";

const validCodes = {
  "THINK-7581-ENDM": 20,
  "ENDEM-IT-9234": 30,
  "TKT-END-4729": 50,
  "TI-ENDM-8831": 70,
  "LUCK-TI-5392": 10,
  "THINK500-8147": 40,
  "ENDM-GIFT-2643": 25,
  "IT-ONLY-9123": 15,
  "TKT-WIN-6688": 60,
  "RWRD-ENDM-7400": 35,
};

const winnerHistory = [
  { name: "Anjali S.", amount: 400 },
  { name: "Rahul T.", amount: 300 },
  { name: "Sneha R.", amount: 200 },
  { name: "Vikram P.", amount: 350 },
  { name: "Pooja K.", amount: 250 },
];

export default function LotterySystem() {
  const [step, setStep] = useState(1);
  const [code, setCode] = useState("");
  const [isValidCode, setIsValidCode] = useState(false);
  const [upiID, setUpiID] = useState("");
  const [prize, setPrize] = useState(null);

  const handleCodeSubmit = () => {
    const enteredCode = code.trim().toUpperCase();
    if (validCodes.hasOwnProperty(enteredCode)) {
      setPrize(validCodes[enteredCode]);
      setIsValidCode(true);
      setStep(2);
    } else {
      alert("\u274C Invalid code. Please try again.");
    }
  };

  const handleUPISubmit = async () => {
    if (!upiID.trim()) return alert("\u26A0\uFE0F Please enter a valid UPI ID");
    setStep(3);
    console.log("User submitted:", { upi: upiID, prize, code });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-100 to-red-100 p-4 flex flex-col items-center justify-center">
      <motion.h1
        className="text-4xl font-bold text-center mb-4 text-amber-800"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        🏱 Think It Snack Lottery – Win up to ₹500!
      </motion.h1>

      <Card className="w-full max-w-xl bg-white shadow-2xl rounded-2xl mb-6">
        <CardContent className="p-6">
          <div className="text-left mb-6 text-gray-800 text-sm leading-relaxed">
            <h2 className="text-lg font-semibold text-green-700 mb-2">📜 How to Win:</h2>
            <ol className="list-decimal ml-5 space-y-2">
              <li>🛒 <strong>Place an order worth ₹150 or more</strong> on our <a className="text-blue-500 underline" href="https://thinkit-74558.store.shoopy.in/categories/snack-443681" target="_blank">Snack Store</a>.</li>
              <li>📩 <strong>Receive a special WhatsApp code</strong> after completing your order.</li>
              <li>🔐 <strong>Paste that code</strong> in the field below and submit it.</li>
              <li>✅ If the code is correct, you'll be asked to <strong>enter your UPI ID</strong>.</li>
              <li>💰 After UPI verification, <strong>you will receive your prize</strong> (up to ₹500) within <strong>24 hours</strong>!</li>
            </ol>
          </div>

          {step === 1 && (
            <div className="space-y-4">
              <Input
                placeholder="🔑 Enter your lucky code"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="rounded-xl"
              />
              <Button onClick={handleCodeSubmit} className="bg-green-600 text-white rounded-xl w-full">
                🎯 Submit Code & Continue
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <p className="text-sm text-gray-700">
                🟢 Code verified! Now enter your UPI ID to receive your reward.
              </p>
              <Input
                placeholder="📲 example@upi"
                value={upiID}
                onChange={(e) => setUpiID(e.target.value)}
                className="rounded-xl"
              />
              <Button onClick={handleUPISubmit} className="bg-blue-600 text-white rounded-xl w-full">
                🧾 Verify UPI & Claim Prize
              </Button>
            </div>
          )}

          {step === 3 && (
            <motion.div
              className="text-center"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <div className="text-2xl font-bold text-green-700 flex items-center justify-center gap-2">
                🪙 <IndianRupee size={24} /> {prize}
              </div>
              <p className="text-sm text-gray-600 mt-2">
                {prize > 0
                  ? "🎉 Congratulations! You’ll receive your reward via UPI within 24 hours."
                  : "😔 Sorry, this time the reward is ₹0. Better luck next time!"}
              </p>
              <BadgeCheck className="text-green-500 mx-auto mt-3" size={32} />
            </motion.div>
          )}
        </CardContent>
      </Card>

      <Card className="w-full max-w-xl bg-white shadow-lg rounded-2xl">
        <CardContent className="p-4">
          <h2 className="text-md font-semibold mb-3 flex items-center gap-2 text-yellow-600">
            <Trophy size={20} /> Recent Winners
          </h2>
          <ul className="text-sm text-gray-700 space-y-1">
            {winnerHistory.map((winner, index) => (
              <li key={index} className="flex justify-between">
                <span>🏅 {winner.name}</span>
                <span>₹{winner.amount}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <p className="text-xs text-gray-500 mt-4 text-center max-w-xs">
        🔐 This system is secure and fair. Each valid order gets one entry. UPI rewards will be verified and disbursed within 24 hours.
      </p>
    </div>
  );
}